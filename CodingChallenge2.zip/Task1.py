nums = [1, 2, 3, 6, 8, 12, 20, 32, 46, 85]
new = []
for i in range(len(nums)):
    if(nums[i] < 5):
        new.append(nums[i])
print(new)
