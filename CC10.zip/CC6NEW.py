import arcpy,os

#make output directory
basePath = r'C:\Users\johnt801\Downloads\ALL_FILES\Step_2_Data'
arcpy.env.workspace = basePath
outPath = os.path.join(arcpy.env.workspace,'outputNDVI')
if not os.path.exists(outPath):
    os.makedirs(outPath)

arcpy.env.overwriteOutput = True

#get list of image folders
dirFolders = os.listdir(arcpy.env.workspace)
imageFolders = []

#assume first character of image folders is numeric
[imageFolders.append(x) for x in dirFolders if x[8].isnumeric()]
print(imageFolders)


#loop through folders and create NDVI based on provided band rasters
for folder in imageFolders:

    arcpy.env.workspace = os.path.join(basePath,folder)
    listRaster = arcpy.ListRasters('*','TIF')
    prefix = listRaster[0][0:42]

    band5 = prefix + '5.tif'
    band4 = prefix + '4.tif'

    print("Creating NDVI for folder %s...\n" % folder)


    outNDVI = arcpy.sa.RasterCalculator([band5,band4],['NIR','Red'],'(NIR-Red)/(NIR+Red)','FirstOf')
    outNDVI.save(str(outPath + "\\NDVI_%s" % folder[7:]))

print("All NDVIs created successfully!")
